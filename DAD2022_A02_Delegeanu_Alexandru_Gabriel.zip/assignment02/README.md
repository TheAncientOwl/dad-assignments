Task:
  Build SNMP client program which is able to send SNMP traps in Java over HTTP or Websocket.

Logics:
  TrapReceiver -> receive traps
  TrapSender -> send trap

Entry Point: Main

OS: Ubuntu 22.04.1 LTS on Windows 10 x86_64

How to run: ./compile-and-run.sh
