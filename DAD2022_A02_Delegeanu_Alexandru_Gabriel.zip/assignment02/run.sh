cd ./bin
sudo java -cp .:../lib/* Main
