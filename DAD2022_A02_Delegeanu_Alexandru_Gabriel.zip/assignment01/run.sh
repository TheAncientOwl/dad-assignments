java -cp bin Main
