mpicc mpi_add_arrays.c -o mpi_add_arrays.out 
mpirun -np 4 mpi_add_arrays.out 
