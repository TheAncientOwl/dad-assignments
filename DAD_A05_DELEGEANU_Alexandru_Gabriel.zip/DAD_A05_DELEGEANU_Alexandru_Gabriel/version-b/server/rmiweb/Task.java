package rmiweb;

public interface Task<T> {
  T execute();
}
