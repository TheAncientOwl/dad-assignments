echo ">> Compilation started..."
./compile.sh

echo ">> Run Main"
./run.sh
