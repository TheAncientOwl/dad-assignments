package eu.ase.httpserver;

public class ReflectionClass {
  public String sampleDoGet() {
    return "This is the output from ReflectionClass.sampleDoGet()";
  }
}
