cd 3.5 && ./compile-and-run.sh && cd ..
