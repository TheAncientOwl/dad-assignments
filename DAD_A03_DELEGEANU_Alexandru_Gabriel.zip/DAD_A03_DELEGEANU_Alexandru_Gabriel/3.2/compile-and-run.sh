gcc -pthread -o main.o main.c
./main.o
