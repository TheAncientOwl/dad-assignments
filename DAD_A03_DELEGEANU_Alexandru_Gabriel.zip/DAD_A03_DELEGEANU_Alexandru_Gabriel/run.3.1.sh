cd 3.1 && ./compile-and-run.sh && cd ..
