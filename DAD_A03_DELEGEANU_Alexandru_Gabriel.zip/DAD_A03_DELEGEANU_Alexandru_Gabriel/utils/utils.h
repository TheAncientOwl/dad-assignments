#pragma once

#include "ANSIColors.h"
#include "timer.h"
#include "printResultArray.h"
