g++ -std=c++17 -pthread -o main.o main.cpp 
./main.o 
