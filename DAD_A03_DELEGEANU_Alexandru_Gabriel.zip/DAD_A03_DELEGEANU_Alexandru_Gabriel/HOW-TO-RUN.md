# OS: Ubuntu 22.04.1 LTS on Windows 10 x86_64

# How to run: (from assignment03 working dir)
  add-arrays-c-cpp:
    3.1: ./run.3.1.sh
    3.2: ./run.3.2.sh
    3.3: ./run.3.3.sh  
    3.4: ./run.3.4.sh
  
  client-server-java:
    3.5: ./run.3.5.sh
