cd 3.4 && ./compile-and-run.sh && cd ..
