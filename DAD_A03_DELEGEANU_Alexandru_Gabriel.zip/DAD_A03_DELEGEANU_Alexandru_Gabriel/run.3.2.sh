cd 3.2 && ./compile-and-run.sh && cd ..
