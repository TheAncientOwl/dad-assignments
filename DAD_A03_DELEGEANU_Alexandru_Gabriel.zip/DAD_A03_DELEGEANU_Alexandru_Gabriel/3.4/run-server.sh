g++ -std=c++17 -o main_server.o udp/sockets/*.cpp udp/addarrays/*.cpp main_server.cpp 
./main_server.o 
