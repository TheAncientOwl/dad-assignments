g++ -std=c++17 -o main_client.o udp/sockets/*.cpp udp/addarrays/*.cpp main_client.cpp 
./main_client.o 
