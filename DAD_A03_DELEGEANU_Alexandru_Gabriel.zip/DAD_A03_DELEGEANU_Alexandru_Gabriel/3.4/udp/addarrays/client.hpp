#pragma once

#include <cstdint>

namespace udp::addarrays {
  void runClient(const int ARRAY_SIZE, const uint16_t PORT);
} // namespace udp::addarrays
