#pragma once

#include <cstdint>

namespace udp::addarrays {
  void runServer(const int ARRAY_SIZE, const uint16_t PORT);
} // namespace udp::addarrays
