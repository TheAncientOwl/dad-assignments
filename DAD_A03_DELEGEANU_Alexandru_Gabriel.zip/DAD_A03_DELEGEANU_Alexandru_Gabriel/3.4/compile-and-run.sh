g++ -pthread -std=c++17 -o main.o udp/sockets/*.cpp udp/addarrays/*.cpp main.cpp 
./main.o 
