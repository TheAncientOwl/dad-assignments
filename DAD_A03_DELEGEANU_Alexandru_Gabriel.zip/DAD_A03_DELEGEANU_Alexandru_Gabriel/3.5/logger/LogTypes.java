package logger;

public enum LogTypes {
  CLIENT,
  SERVER,
  INFO
}
