gcc -std=gnu99 -o main.o main.c
./main.o
