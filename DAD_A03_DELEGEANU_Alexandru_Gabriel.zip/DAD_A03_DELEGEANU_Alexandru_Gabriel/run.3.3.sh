cd 3.3 && ./compile-and-run.sh && cd ..
